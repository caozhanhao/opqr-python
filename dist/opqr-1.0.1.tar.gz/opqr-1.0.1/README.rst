# opqr-python

## Introduction
- A Simple QR encode Library.
## Useage
```python
import opqr
qr = opqr.encode("opqr")
qr.image("qr.bmp")
```
## Note
- There may be bugs in Kanji Mode
## Reference
[二维码生成原理](https://zhuanlan.zhihu.com/p/543574464)
